package Driver;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
 
import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageTypeSpecifier;
import javax.imageio.ImageWriter;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.plugins.jpeg.JPEGImageWriteParam;
import javax.imageio.stream.ImageOutputStream;
 
import org.w3c.dom.Element;
 
 
public class ImgCompressUtil { 
	 
    /**
   * ͼƬѹ������
   * @param args
   */
  public static void main(String args[]){ 
  
    String url = "F:\\FMS_REPLAY_MEDIA\\img\\";
    String name  =  "sd456asd.gif";
    name = "9d8608c7ea288a691b03ae5e0604de06.jpg";
    Tosmallerpic(url,url,name,188,165,(float)0.85);
    System.out.println("");
  }
  
   
  /** 
  * 
  * @param srcFilePath ͼƬ���ڵ��ļ���·�� 
  * @param destFilePath ���·�� 
  * @param name ͼƬ�� 
  * @param w Ŀ��� 
  * @param h Ŀ��� 
  * @param per �ٷֱ� 
  */ 
  private static void  Tosmallerpic(String srcFilePath,String destFilePath,String name,int w,int h,float per){ 
          Image src; 
          try { 
              src  =  javax.imageio.ImageIO.read(new File(srcFilePath+File.separator+name)); //����Image���� 
             String img_midname  =  destFilePath + File.separator + "c_"+name; 
             int old_w = src.getWidth(null); 
             int old_h = src.getHeight(null); 
             int new_w = 0; 
             int new_h = 0;
 
             double w2 = (old_w*1.00)/(w*1.00); 
             double h2 = (old_h*1.00)/(h*1.00); 
 
          
             BufferedImage oldpic; 
             if(old_w>old_h) 
             { 
                 oldpic = new BufferedImage(old_w,old_w,BufferedImage.TYPE_INT_RGB); 
             }else{if(old_w<old_h){ 
                 oldpic = new BufferedImage(old_h,old_h,BufferedImage.TYPE_INT_RGB); 
             }else{ 
                  oldpic = new BufferedImage(old_w,old_h,BufferedImage.TYPE_INT_RGB); 
             } 
             } 
              Graphics2D g  =  oldpic.createGraphics(); 
              g.setColor(Color.white); 
              if(old_w>old_h) 
              { 
                  g.fillRect(0, 0, old_w, old_w); 
                  g.drawImage(src, 0, (old_w - old_h) / 2, old_w, old_h, Color.white, null); 
              }else{ 
                  if(old_w<old_h){ 
                  g.fillRect(0,0,old_h,old_h); 
                  g.drawImage(src, (old_h - old_w) / 2, 0, old_w, old_h, Color.white, null); 
                  }else{ 
                   
                      g.drawImage(src.getScaledInstance(old_w, old_h,  Image.SCALE_SMOOTH), 0,0,null); 
                  } 
              }              
              g.dispose(); 
              src  =  oldpic; 
             if(old_w>w) 
             new_w = (int)Math.round(old_w/w2); 
             else 
                 new_w = old_w; 
             if(old_h>h) 
             new_h = (int)Math.round(old_h/h2);
             else 
                 new_h = old_h; 
             BufferedImage image_to_save  =  new BufferedImage(new_w,new_h,BufferedImage.TYPE_INT_RGB);        
             image_to_save.getGraphics().drawImage(src.getScaledInstance(new_w, new_h,  Image.SCALE_SMOOTH), 0,0,null); 
             FileOutputStream fos = new FileOutputStream(img_midname); 

             saveAsJPEG(100, image_to_save, per, fos);
              
             fos.close(); 
             } catch (IOException ex) { 

          } 
  } 
   
	/**
	   * ��JPEG���뱣��ͼƬ
	   * @param dpi  �ֱ���
	   * @param image_to_save  Ҫ������ͼ��ͼƬ
	   * @param JPEGcompression  ѹ����
	   * @param fos �ļ������
	   * @throws IOException
	   */
	  public static void saveAsJPEG(Integer dpi ,BufferedImage image_to_save, float JPEGcompression, FileOutputStream fos) throws IOException {
	        
		  ImageWriter imageWriter  =   ImageIO.getImageWritersBySuffix("jpg").next();
	      ImageOutputStream ios  =  ImageIO.createImageOutputStream(fos);
	      imageWriter.setOutput(ios);

	      IIOMetadata imageMetaData  =  imageWriter.getDefaultImageMetadata(new ImageTypeSpecifier(image_to_save), null);
	       
	       
	      if(dpi !=  null && !dpi.equals("")){
	           
	          Element tree  =  (Element) imageMetaData.getAsTree("javax_imageio_jpeg_image_1.0");
	          Element jfif  =  (Element)tree.getElementsByTagName("app0JFIF").item(0);
	          jfif.setAttribute("Xdensity", Integer.toString(dpi) );
	          jfif.setAttribute("Ydensity", Integer.toString(dpi));
	           
	      }
	    
	    
	      if(JPEGcompression >= 0 && JPEGcompression <= 1f){
	    

	          JPEGImageWriteParam jpegParams  =  (JPEGImageWriteParam) imageWriter.getDefaultWriteParam();
	          jpegParams.setCompressionMode(JPEGImageWriteParam.MODE_EXPLICIT);
	          jpegParams.setCompressionQuality(JPEGcompression);
	    
	      }
	    

	      imageWriter.write(imageMetaData, new IIOImage(image_to_save, null, null), null);
	      ios.close();
	      imageWriter.dispose();
	    
	  }
}