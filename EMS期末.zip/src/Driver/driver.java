package Driver;

import java.io.IOException;
import java.util.ArrayList;

import Service.ImgToPdf;
import Service.QRcode;
import Service.imageControl;
import Service.jxlControl;
import base.Information;

public class driver {
	public static void main(String[] args) {
		String format=base.global.FORMAT;
		String fileName =base.global.FILENAME;
		ArrayList<Information>list = jxlControl.readFromExcel(fileName);
		System.out.println("�������");
		imageControl.control(format, list);
		System.out.println("ͼƬ������ɣ���export�в鿴��ֻ��ǰ�����ǽ��������ֻ��һά��");
		for(int i=1;i<4;i++) {
			try {
				String imgSrc=base.global.PICPLACE+base.global.TAG+String.valueOf(i)+base.global.FORMAT;
				String pdfSrc = base.global.PICPLACE+"pdf"+String.valueOf(i)+".pdf";
				ImgToPdf.imgToPdf(imgSrc,pdfSrc);
				System.out.println(pdfSrc+"�������");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
}
