package base;

public class global {
	public static final String FILENAME = "./source/�����ļ�.xls";
	public static final String FORMAT=".jpg";
	public static final String PICPLACE = "./export/";
	public final static int TEXTCOLOR = 0xFFFFFFFF;
	public final static int BACKCOLOR = 0xFF00000;
	public final static int IMAGEWIDTH = 955;
	public final static int IMAGEHEIGHT = 1400;
	public final static String TAG="pic";
}
